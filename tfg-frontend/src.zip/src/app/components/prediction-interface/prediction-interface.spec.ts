import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PredictionInterface } from './prediction-interface';

describe('PredictionInterface', () => {
  let component: PredictionInterface;
  let fixture: ComponentFixture<PredictionInterface>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PredictionInterface]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PredictionInterface);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
