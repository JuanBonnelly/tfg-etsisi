import { Component } from '@angular/core';

@Component({
  selector: 'app-prediction-interface',
  imports: [],
  templateUrl: './prediction-interface.html',
  styleUrl: './prediction-interface.scss'
})
export class PredictionInterface {

}
